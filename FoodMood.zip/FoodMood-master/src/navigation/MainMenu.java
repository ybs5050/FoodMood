package navigation;


import java.awt.event.ActionEvent;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * FXML Controller Class
 * @author
 */
public class MainMenu {
    
    /**
     * Initializes the controller class
     */
    public void initialize() {
        
    }
    
    /**
     * Opens a new scene from FoodMoodList class
     * @param event "View Mood Food" button action
     */
    public void viewFoodMoodList(ActionEvent event) {
        
    }
    
}
